package semana_01;

public class Variables {
	public static void main(String[] args) {
		int numero1, numero2, suma;
		double division;
		numero1 = 30;
		numero2 = 20;
		
		//suma = numero1 + numero2;
		division = numero1*1.0/numero2;
		
		//System.out.println(suma);
		System.out.println(division);
		
		//String numero = "24.5";
		//System.out.print(Double.parseDouble(numero));

	}
	
}
