package semana_01;

public class Conversiones {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String cadena1 = "10.7";
		String cadena2 = "20.8";
		
		double numero1 = Double.parseDouble(cadena1);
		System.out.println(numero1);

	}

}
