package semana_01;

public class Operadores {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int numero1 = 20, numero = 6;
		int residuo = 20%6;
		System.out.println(residuo);
		
		
		

	}

}
