package ec_02.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Ejercicio_01 extends JFrame implements ActionListener {

	private JPanel contentPane;
	private final JButton btnProcesar = new JButton("Procesar");
	private final JLabel lblNewLabel = new JLabel("N\u00B0 Terminos:");
	private final JTextField txtNumero = new JTextField();
	private final JScrollPane scrollPane = new JScrollPane();
	private final JTextArea txtSalida = new JTextArea();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ejercicio_01 frame = new Ejercicio_01();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ejercicio_01() {
		txtNumero.setBounds(124, 13, 146, 26);
		txtNumero.setColumns(10);
		initGUI();
	}
	private void initGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 556, 413);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		btnProcesar.addActionListener(this);
		btnProcesar.setBounds(404, 36, 115, 29);
		
		contentPane.add(btnProcesar);
		lblNewLabel.setBounds(15, 16, 126, 20);
		
		contentPane.add(lblNewLabel);
		
		contentPane.add(txtNumero);
		scrollPane.setBounds(15, 111, 504, 230);
		
		contentPane.add(scrollPane);
		
		scrollPane.setViewportView(txtSalida);
	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnProcesar) {
			actionPerformedBtnProcesar(e);
		}
	}
	protected void actionPerformedBtnProcesar(ActionEvent e) {
		int numeroTerminos;		
		double pi;
		numeroTerminos = Integer.parseInt(txtNumero.getText());
		pi = calcularPi(numeroTerminos);
		
		
		txtSalida.setText(null);		
		txtSalida.append("Valor de pi: " + pi);
		
	}
	
	double calcularPi (int n) {
		int d = 1, signo = 1;
		double t, s = 0;
		for (int i =1; i <= n; i++) {
			t =  1.0 / d * signo;
			s += t;
			d += 2;
			signo *= -1;			
		}
		
		return s*4 ;
	}
}
